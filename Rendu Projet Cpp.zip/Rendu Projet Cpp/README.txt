-------------------------------------------------------------------

PROJET DE C++ ------ Tom JULLIEN & Thomas BOURSAC 

-------------------------------------------------------------------

Ce README est un mode d'emplois pour utiliser notre projet. 

Afin d'executer le projet, il est nécessaire de posséder les librairies nécessaires disponibles dans le dossier.
Ensuite il suffit de brancher la carte Arduino Uno à l'aide du cable dans la boite et de compiler/televerser le programme sur la carte. 

N'hésitez pas à nous contacter pour toutes questions ou problèmes. 


